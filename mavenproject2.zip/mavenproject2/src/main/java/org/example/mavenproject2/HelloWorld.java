/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.example.mavenproject2;

import javax.crypto.spec.*;
import java.security.*;
import javax.crypto.*;
import org.owasp.esapi.crypto.CipherText; 

import java.io.InputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import java.io.ByteArrayInputStream;
import java.lang.ClassLoader;

import java.io.FileInputStream;
import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;



/**
 *
 * @author f3l1p3x
 */
public class HelloWorld {
    public static void main(String []args) throws Exception {
        //ClassLoader classLoader = getClass().getClassLoader();
        //File file = new File(classLoader.getResource("DefaultRts.txt").getFile());
        
         int decimal = hex2Decimal("afasdfsdaf");
         System.out.println("decimal "+decimal);

        InputStream is = ClassLoader.getSystemResourceAsStream("DefaultRts.txt");
        //byte[] encrypted = new byte[is.available()];
        //is.read(encrypted);
        
        byte[] encrypted = IOUtils.toByteArray(is);
        
        
       
        for(int i=0 ; i < encrypted.length ; i++) {
            System.out.print(encrypted[i]+" ");
        }
        System.out.println();
        //String decrypted = decrypt(encrypted, "30000000 00000000");
        
        // esto no funcionó... byte[] encrypted = IOUtils.toByteArray(is);

        String toEncrypt = "10000000 00000001";
  
        System.out.println("Encrypting..."+toEncrypt+"\n");
        encrypted = encrypt(toEncrypt, "30000000 00000000");
      //System.out.print(new String(encrypted));
        for(int i=0; i< encrypted.length ; i++) { 
            System.out.print(encrypted[i] +" ");
        }
        
        System.out.println("\n"+"Decrypting...");
        String decrypted = decrypt(encrypted, "30000000 00000000");
        System.out.println("Decrypted text: " + decrypted);
}
    
    public static int hex2Decimal(String s) {
        String digits = "0123456789ABCDEF";
        s = s.toUpperCase();
        int val = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int d = digits.indexOf(c);
            val = 16*val + d;
        }
        return val;
    }
    
    public static byte[] encrypt(String toEncrypt, String key) throws Exception {
      // create a binary key from the argument key (seed)
      SecureRandom sr = new SecureRandom(key.getBytes());
      KeyGenerator kg = KeyGenerator.getInstance("RC2");
      kg.init(sr);
      SecretKey sk = kg.generateKey();
  
      // create an instance of cipher
      Cipher cipher = Cipher.getInstance("RC2");
  
      // initialize the cipher with the key
      cipher.init(Cipher.ENCRYPT_MODE, sk);
  
      // enctypt!
      byte[] encrypted = cipher.doFinal(toEncrypt.getBytes());
  
      return encrypted;
   }
   
    public static String decrypt(byte[] toDecrypt, String key) throws Exception {
      // create a binary key from the argument key (seed)
      SecureRandom sr = new SecureRandom(key.getBytes());
      KeyGenerator kg = KeyGenerator.getInstance("RC2");
      kg.init(sr);
      SecretKey sk = kg.generateKey();
  
      // do the decryption with that key
      Cipher cipher = Cipher.getInstance("RC2");
      cipher.init(Cipher.DECRYPT_MODE, sk);
      byte[] decrypted = cipher.doFinal(toDecrypt);
  
      return new String(decrypted);
   }
    
}
