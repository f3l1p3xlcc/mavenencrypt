/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.example.mavenproject2;

import javax.crypto.spec.*;
import java.security.*;
import javax.crypto.*;
import org.owasp.esapi.crypto.CipherText; 

import java.io.InputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import java.io.ByteArrayInputStream;
import java.lang.ClassLoader;

import java.io.FileInputStream;
import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import javax.xml.bind.DatatypeConverter;


/**
 *
 * @author f3l1p3x
 */
public class HelloWorld {
    public static void main(String []args) throws Exception {
        //ClassLoader classLoader = getClass().getClassLoader();
        //File file = new File(classLoader.getResource("DefaultRts.txt").getFile());

        InputStream is = ClassLoader.getSystemResourceAsStream("DefaultRts.txt");
        
        String passfromtext = IOUtils.toString(is, "UTF-8");
        System.out.println("passfromtext "+passfromtext);

        byte[] encryptedfromtext = toByteArray(passfromtext);

        System.out.println();  
        String decryptedstring = decrypt(encryptedfromtext, "30000000 00000000");
        System.out.println("decryptedstring "+decryptedstring);

        String toEncrypt = "abc";
  
        System.out.println("Encrypting..."+toEncrypt+"\n");
        byte[] encrypted = encrypt(toEncrypt, "00000000"); 
        
        String hexstring = toHexString(encrypted);  
        System.out.println("hexstring "+hexstring);
        
        
       // String decryptedstring = decrypt(encrypted, "00000000");
        System.out.print("decryptedstring "+decryptedstring+"\n");
         
        String decrypthexstring = toHexString(encrypted);
        System.out.print("enriptedstring "+decrypthexstring +"\n"); 
                
        for(int i=0; i< encrypted.length ; i++) {
            System.out.print(encrypted[i] +" ");
        }
        
        System.out.println("\n"+"Decrypting...");
        String decrypted = decrypt(encrypted, "00000000");
        System.out.println("Decrypted text: " + decrypted);
}
   
    public static byte[] encrypt(String toEncrypt, String key) throws Exception {
      // create a binary key from the argument key (seed)
      SecureRandom sr = new SecureRandom(key.getBytes());
      KeyGenerator kg = KeyGenerator.getInstance("RC2");
      kg.init(sr);
      SecretKey sk = kg.generateKey();
  
      // create an instance of cipher
      Cipher cipher = Cipher.getInstance("RC2");
  
      // initialize the cipher with the key
      cipher.init(Cipher.ENCRYPT_MODE, sk);
  
      // enctypt!
      byte[] encrypted = cipher.doFinal(toEncrypt.getBytes());
  
      return encrypted;
   }
   
    public static String decrypt(byte[] toDecrypt, String key) throws Exception {
      // create a binary key from the argument key (seed)
      SecureRandom sr = new SecureRandom(key.getBytes());
      KeyGenerator kg = KeyGenerator.getInstance("RC2");
      kg.init(sr);
      SecretKey sk = kg.generateKey();
  
      // do the decryption with that key
      Cipher cipher = Cipher.getInstance("RC2");
      cipher.init(Cipher.DECRYPT_MODE, sk);
      byte[] decrypted = cipher.doFinal(toDecrypt);
  
      return new String(decrypted);
   }
    
    private static byte[] toByteArray(String s) {
        return DatatypeConverter.parseHexBinary(s);
    }

    private static String toHexString(byte[] array) {
        return DatatypeConverter.printHexBinary(array).toLowerCase();
    }

    
}
